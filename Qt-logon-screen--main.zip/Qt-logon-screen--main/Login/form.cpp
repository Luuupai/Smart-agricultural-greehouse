#include "form.h"
#include "ui_form.h"

Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);


    QPalette PAllbackground = this->palette();
    QImage ImgAllbackground("://bg2.jpg");
    QImage fitimgpic=ImgAllbackground.scaled(this->width(),this->height(), Qt::IgnoreAspectRatio);
    PAllbackground.setBrush(QPalette::Window, QBrush(fitimgpic));
    this->setPalette(PAllbackground);

}

Form::~Form()
{
    delete ui;
}

void Form::connectSuccess()
{
    QMessageBox::about(NULL,"提示","MQTT连接成功");
}
void Form::on_pushButton_clicked()
{
    client = new QMqttClient;
    client->setHostname("mqtt.yyzlab.com.cn");
    client->setPort(1883);
    client->connectToHost();
    connect(client,SIGNAL(connected()),this,SLOT(connectSuccess()));
    connect(client,SIGNAL(messageReceived(QByteArray,QMqttTopicName)),this,SLOT(readData(QByteArray,QMqttTopicName)));

}
void Form::on_pushButton_2_clicked()
{
   client->publish(ui->lineEdit_3->text(),ui->lineEdit_4->text().toUtf8());//发布

}

void Form::on_pushButton_3_clicked()
{
    client->subscribe(ui->lineEdit_5->text());//订阅
}

void Form::readData(QByteArray buf,QMqttTopicName)
{
    qDebug() << buf;
    QJsonDocument jdoc = QJsonDocument::fromJson(buf);
    QJsonObject jobj = jdoc.object();

    if(jobj.contains("soiltem"))
         {
             QJsonValue json_TR_S = jobj.value("soilhum");
             QString json_string1 = QString::number( json_TR_S.toDouble());
             ui->lineEdit_6->setText(json_string1);

             QJsonValue json_TR_T = jobj.value("soiltem");
             QString json_string2 = QString::number( json_TR_T.toDouble());
             ui->lineEdit_7->setText(json_string2);
         }

                         /*显示co2浓度*/
     else if(jobj.contains("co2"))
         {
            QJsonValue json_CO2 = jobj.value("co2");
            QString json_string5 = QString::number( json_CO2.toDouble());
            ui->lineEdit_9->setText(json_string5);
         }
                          /*显示光照强度*/
     else if(jobj.contains("light"))
         {
            QJsonValue json_GZ = jobj.value("light");
            QString json_string6 = QString::number( json_GZ.toDouble());//double转换为QString
            ui->lineEdit_8->setText(json_string6);
         }


}




