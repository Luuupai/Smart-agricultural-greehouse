#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QPixmap>
#include <QtMqtt/qmqttclient.h>
#include <QMessageBox>
#include <QDebug>
#include <QJsonObject>
#include <QJsonValue>
#include <QJsonDocument>
#include <QTcpSocket>
#include <QHostAddress>
#include <QDataStream>

namespace Ui {
class Form;
}

class Form : public QWidget
{
    Q_OBJECT
private slots:
    void connectSuccess();

   // void on_pushButton_4_clicked();

    void on_pushButton_3_clicked();

    void readData(QByteArray,QMqttTopicName);

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

public:
    explicit Form(QWidget *parent = 0);
    ~Form();

private:
    Ui::Form *ui;
    QPixmap pix;
    QMqttClient *client;
};

#endif // FORM_H
